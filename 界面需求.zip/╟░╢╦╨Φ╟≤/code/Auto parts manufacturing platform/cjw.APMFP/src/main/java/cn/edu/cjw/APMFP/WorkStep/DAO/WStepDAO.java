package cn.edu.cjw.APMFP.WorkStep.DAO;

import java.util.ArrayList;

import cn.edu.cjw.APMFP.WorkStep.pojo.WorkStep;

public interface WStepDAO {

	//新增更新工序
	public boolean addAndUpdateWStep(WorkStep ws) throws Exception;
	
	//删除工序
	public boolean removeWStep(WorkStep ws) throws Exception;
	
	//搜索工序
	//按工序名称
	public ArrayList<WorkStep> searchWStepByName(String name) throws Exception;
	
	//按工序编号
	public WorkStep searchWStepById(String id) throws Exception;
	
	//展示所有工序
	public ArrayList<WorkStep> showAll() throws Exception;
}
