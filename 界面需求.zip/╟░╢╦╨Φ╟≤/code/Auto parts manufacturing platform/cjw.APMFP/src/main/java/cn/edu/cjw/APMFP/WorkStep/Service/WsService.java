package cn.edu.cjw.APMFP.WorkStep.Service;

import java.util.ArrayList;

import cn.edu.cjw.APMFP.WorkStep.pojo.WorkStep;

public interface WsService {

	//创建工序
	public boolean AddWStep(String WId,String WName,String WDescribe) throws Exception;
	
	//删除工序
	public boolean removeWStep(WorkStep wStep) throws Exception;
	
	//修改工序名称
	public boolean updateWStepName(WorkStep wStep,String nName) throws Exception;
	
	//修改工序备注
	public boolean updateWStepDescribe(WorkStep wStep,String nDescribe) throws Exception;
	
	//总体修改
	public boolean updateWStep(WorkStep wStep,String nName,String nDescribe) throws Exception;
	
	//搜索工序
	//按编号
	public WorkStep searchWStepById(String id) throws Exception;
	
	//按名称
	public ArrayList<WorkStep> searchWStepByName(String name) throws Exception;
	
	//展示所有工序
	public ArrayList<WorkStep> showAll() throws Exception;
	
}
