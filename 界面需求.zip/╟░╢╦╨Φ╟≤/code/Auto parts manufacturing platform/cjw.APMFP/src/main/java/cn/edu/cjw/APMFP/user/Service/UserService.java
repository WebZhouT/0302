package cn.edu.cjw.APMFP.user.Service;

import java.util.ArrayList;

import cn.edu.cjw.APMFP.RoleRight.pojo.RoleRight;
import cn.edu.cjw.APMFP.user.pojo.user;

public interface UserService {

	/**
	 * 账号唯一不允许修改
	 * @return
	 * @throws Exception
	 */
	
	//展示所有员工
	public ArrayList<user> showAll() throws Exception;
	
	// 新增员工
	public boolean addUser(user user) throws Exception ;

	// 删除员工
	public boolean removeUSer(user user) throws Exception;

	// 修改员工密码
	public boolean updateUserPassword(user user, String newPasswd) throws Exception;

	// 修改员工姓名
	public boolean updateUserName(user user, String newName) throws Exception;

	// 修改员工角色
	public boolean updateUserRole(user user, RoleRight newRole) throws Exception;

	// 修改员工性别
	public boolean updateUserGender(user user, String newGender) throws Exception;

	// 修改员工年龄
	public boolean updateUserAge(user user, int newAge) throws Exception;

	// 员工账号停用
	public boolean updateUserIsdeactivate(user user, boolean newDtive) throws Exception;
	
	//总体修改
	public boolean updateUser(user user, String newPasswd, String newName, RoleRight newRole, String newGender, int newAge, boolean newDtive) throws Exception;

	// 按工号搜索员工
	public user SearchUserByAccount(String account) throws Exception ;

	// 按姓名搜索员工
	public ArrayList<user> SearchUserByName(String name) throws Exception;

	// 按角色搜索员工
	public ArrayList<user> SearchUserByRole(RoleRight right) throws Exception;

}
