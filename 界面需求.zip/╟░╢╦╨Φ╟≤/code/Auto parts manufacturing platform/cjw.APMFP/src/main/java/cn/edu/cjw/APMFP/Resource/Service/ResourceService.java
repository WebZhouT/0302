package cn.edu.cjw.APMFP.Resource.Service;

import java.util.ArrayList;

import cn.edu.cjw.APMFP.BOMTable.pojo.BOMTable;
import cn.edu.cjw.APMFP.ProductionTask.pojo.ProductionTask;
import cn.edu.cjw.APMFP.Resource.resource;
import cn.edu.cjw.APMFP.user.pojo.user;

public interface ResourceService {

	//原料入库
	public boolean materialIn(BOMTable bom,Long num,user user) throws Exception;
	
	//原料出库
	public boolean materialOut(ProductionTask task,user user) throws Exception;
	
	//产品入库
	public boolean productIn(ProductionTask task,user user) throws Exception;
	
	//产品出库
	public boolean productOut(BOMTable bom,Long num,user user) throws Exception;
	
	//删除资源
	public boolean removeResource(String bid) throws Exception;
	
	//展示原料库存
	public ArrayList<resource> showMaterial() throws Exception;
	
	//展示产品库存
	public ArrayList<resource> showProduct() throws Exception;
	
	//按名称搜索库存
	public ArrayList<resource> searchResourceByName(String name) throws Exception;
	
	//按编号搜索库存
	public resource searchResourceById(String id) throws Exception;
	
}
