package cn.edu.cjw.APMFP.RoleRight.pojo;

import java.io.Serializable;
import java.util.ArrayList;

import org.apache.commons.lang.StringUtils;

public class RoleRight implements Serializable {

	// 角色编号
	private String RNum;

	// 角色名称
	private String RName;

	// 角色描述
	private String RDescribe;

	// 角色权限
	private ArrayList<String> RRight;

	public static final String ROLE_TABLE_NAME = "apmfp_role_table";

	public RoleRight() {

	}

	public RoleRight(String rNum, String rName, String rDescribe, ArrayList<String> rRight) {
		super();
		RNum = rNum;
		RName = rName;
		RDescribe = rDescribe;
		RRight = rRight;
	}

	public String getRNum() {
		return RNum;
	}

	public void setRNum(String rNum) {
		RNum = rNum;
	}

	public String getRName() {
		return RName;
	}

	public void setRName(String rName) {
		RName = rName;
	}

	public String getRDescribe() {
		return RDescribe;
	}

	public void setRDescribe(String rDescribe) {
		RDescribe = rDescribe;
	}

	public ArrayList<String> getRRight() {
		return RRight;
	}

	public void setRRight(ArrayList<String> rRight) {
		RRight = rRight;
	}

	@Override
	public String toString() {
		return "RNum=" + RNum + ", RName=" + RName + ", RDescribe=" + RDescribe + ", RRight=" + RRight;
	}

	public boolean judge() {

		if (StringUtils.isBlank(RNum)) {
			return false;
		}
		if (StringUtils.isBlank(RName)) {
			return false;
		}
		if (StringUtils.isBlank(RDescribe)) {
			return false;
		}
		if (StringUtils.isBlank(RRight.toString())) {
			return false;
		}

		return true;
	}

}
