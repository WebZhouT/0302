package cn.edu.cjw.APMFP.BOMTable.DAO;

import java.util.ArrayList;

import cn.edu.cjw.APMFP.BOMTable.pojo.BOMTable;

public interface BOMTableDAO {

	//新增、更新资源
	public boolean addAndUpdateBOM(BOMTable bomTable) throws Exception;
	
	//删除资源
	public boolean removeBOM(BOMTable bomTable) throws Exception;
	
	//搜索资源，按编号、名称、类型，单位
	public BOMTable searchById(String id) throws Exception;
	
	public ArrayList<BOMTable> searchByName(String name) throws Exception;
	
	public ArrayList<BOMTable> searchByType(String type) throws Exception;

	public ArrayList<BOMTable> searchByUnit(String unit) throws Exception;
	
	//展示所有资源
	public ArrayList<BOMTable> showAll() throws Exception;

}
