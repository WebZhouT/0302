package cn.edu.cjw.APMFP.Product.DAO;

import java.util.ArrayList;

import cn.edu.cjw.APMFP.Product.pojo.Product;

public interface ProductDAO {

	//新增、更新商品
	public boolean addAndUpdateProduct(Product product) throws Exception;
	
	//删除商品
	public boolean removeProduct(Product product) throws Exception;
	
	//搜索商品
	public Product searchProductById(String pid) throws Exception;
	
	public ArrayList<Product> searchProductByname(String name) throws Exception;

}
