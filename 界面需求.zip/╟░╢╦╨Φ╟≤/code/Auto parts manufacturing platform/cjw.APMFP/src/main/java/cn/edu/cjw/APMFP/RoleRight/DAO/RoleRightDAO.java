package cn.edu.cjw.APMFP.RoleRight.DAO;

import java.util.ArrayList;

import cn.edu.cjw.APMFP.RoleRight.pojo.RoleRight;

public interface RoleRightDAO {

	//展示所有角色
	public ArrayList<RoleRight> showAll() throws Exception;
	
	// 新增角色 及 修改角色
	public boolean addAndUpdateRole(RoleRight r) throws Exception;

	// 删除角色
	public boolean removeRole(RoleRight r) throws Exception;

	// 搜索角色
	public RoleRight SearchRoleByrNUM(String rNum) throws Exception;
	
	public ArrayList<RoleRight> SearchRoleByName(String rName) throws Exception;

}
