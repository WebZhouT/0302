package cn.edu.cjw.APMFP.Product.Servicve;

import java.util.ArrayList;
import java.util.HashMap;

import cn.edu.cjw.APMFP.BOMTable.pojo.BOMTable;
import cn.edu.cjw.APMFP.Product.pojo.Product;

public interface ProductService {

	//新增商品
	public boolean addProduct(BOMTable bomTable,HashMap<String, Long> material,HashMap<Integer, String> workstep) throws Exception;
	
	//更新商品原料
	public boolean updateProductMaterial(Product product,HashMap<String, Long> material) throws Exception;
	
	//更新商品工序
	public boolean updateProductWorkstep(Product product,HashMap<Integer, String> workstep) throws Exception;
	
	//删除商品
	public boolean removeProduct(Product product) throws Exception;
	
	//按编号搜索商品
	public Product searchProductById(String id) throws Exception;
	
	//按名称搜索商品
	public ArrayList<Product> searchProductByName(String name) throws Exception;
}
