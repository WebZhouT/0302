package cn.edu.cjw.APMFP.user.DAO;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import cn.edu.cjw.APMFP.user.pojo.user;

public interface UserDAO {

	//展示所有员工
	public ArrayList<user> showAll() throws Exception;
	
	// 新增员工 and 修改员工信息
	public boolean AddAndUpdateUser(user user) throws Exception;

	// 删除员工
	public boolean RemoveUser(user user) throws Exception;

	// 根据工号搜索员工
	public user SearchUserByAccount(String account) throws Exception;
	
	//根据角色搜索员工
	public ArrayList<user> SearchUsersByRole(String rname) throws Exception;

	// 根据姓名搜索员工
	public ArrayList<user> SearchUserByName(String name) throws Exception;


}
