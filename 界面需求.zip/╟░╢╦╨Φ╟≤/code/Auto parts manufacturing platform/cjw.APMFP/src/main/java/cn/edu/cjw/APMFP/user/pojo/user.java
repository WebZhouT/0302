package cn.edu.cjw.APMFP.user.pojo;

import java.io.Serializable;
import org.apache.commons.lang.StringUtils;

import cn.edu.cjw.APMFP.RoleRight.pojo.RoleRight;

public class user implements Serializable{

	// 员工工号
	private String account;

	// 员工密码，初始为 000000
	private String passWord = "000000";

	// 员工姓名
	private String name;

	// 员工角色
	private RoleRight uRole;

	// 员工性别
	private String gender;

	// 员工年龄
	private int age;

	// 员工账号是否停用
	private boolean Deactivate = false;

	public static final String USER_TABLE_NAME = "apmfp_user_table";
	
	public user() {

	}

	public user(String account, String passWord, String name, RoleRight uRole, String gender, int age,
			boolean deactivate) {
		super();
		this.account = account;
		this.passWord = passWord;
		this.name = name;
		this.uRole = uRole;
		this.gender = gender;
		this.age = age;
		Deactivate = deactivate;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public String getPassWord() {
		return passWord;
	}

	public void setPassWord(String passWord) {
		this.passWord = passWord;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public RoleRight getuRole() {
		return uRole;
	}

	public void setuRole(RoleRight uRole) {
		this.uRole = uRole;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public boolean isDeactivate() {
		return Deactivate;
	}

	public void setDeactivate(boolean deactivate) {
		Deactivate = deactivate;
	}

	@Override
	public String toString() {
		return "account=" + account + ", name=" + name + ", uRole=" + uRole
				+ ", gender=" + gender + ", age=" + age + ", Deactivate=" + Deactivate;
	}

	public boolean judge() {
		
		if (StringUtils.isBlank(account)) {
			return false;
		}
		if (StringUtils.isBlank(name)) {
			return false;
		}
		if (StringUtils.isBlank(uRole.toString())) {
			return false;
		}
		
		return true;
	}
}
