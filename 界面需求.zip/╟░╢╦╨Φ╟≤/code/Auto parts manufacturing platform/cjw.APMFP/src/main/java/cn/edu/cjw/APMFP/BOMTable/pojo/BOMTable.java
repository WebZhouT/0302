package cn.edu.cjw.APMFP.BOMTable.pojo;

import java.io.Serializable;

import org.apache.commons.lang.StringUtils;

public class BOMTable implements Serializable {

	// 编号
	private String BId;

	// 名称
	private String BName;

	// 类型：成品or原料
	private String Btype;

	// 单位
	private String unit;
	
	public static final String TYPE_MATERIAL = "material";
	
	public static final String TYPE_PRODUCT = "product";

	public static final String BOMTABLE_TABLE_NAME = "apmfp_bomtable_table";

	public BOMTable() {
	}

	public BOMTable(String bId, String bName, String btype, String unit) {
		super();
		BId = bId;
		BName = bName;
		Btype = btype;
		this.unit = unit;
	}

	public String getBId() {
		return BId;
	}

	public void setBId(String bId) {
		BId = bId;
	}

	public String getBName() {
		return BName;
	}

	public void setBName(String bName) {
		BName = bName;
	}

	public String getBtype() {
		return Btype;
	}

	public void setBtype(String btype) {
		Btype = btype;
	}

	public String getUnit() {
		return unit;
	}

	public void setUnit(String unit) {
		this.unit = unit;
	}

	@Override
	public String toString() {
		return "BId=" + BId + ", BName=" + BName + ", Btype=" + Btype + ", unit=" + unit;
	}

	public boolean judge() {

		if (StringUtils.isBlank(BId)) {
			return false;
		}
		if (StringUtils.isBlank(BName)) {
			return false;
		}
		if (StringUtils.isBlank(Btype)) {
			return false;
		}

		return true;
	}

}
