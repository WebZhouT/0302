package cn.edu.cjw.APMFP.Resource.DAO;

import java.util.ArrayList;

import cn.edu.cjw.APMFP.Resource.resource;

public interface ResourceDAO {

	//新增更新资源
	public boolean addAndupdate(resource resource) throws Exception;
	
	//删除资源
	public boolean remove(String bid) throws Exception;
	
	//按名称搜索资源
	public ArrayList<resource> searchByName(String name) throws Exception;
	
	//按编号搜索库存
	public resource searchById(String id) throws Exception;
	
	//按类型搜索库存
	public ArrayList<resource> searchByType(String type) throws Exception;
	
}
