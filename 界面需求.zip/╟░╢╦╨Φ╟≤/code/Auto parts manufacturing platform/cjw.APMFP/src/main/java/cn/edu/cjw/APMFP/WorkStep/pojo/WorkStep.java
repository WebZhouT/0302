package cn.edu.cjw.APMFP.WorkStep.pojo;

import java.io.Serializable;

import org.apache.commons.lang.StringUtils;

public class WorkStep implements Serializable{

	// 工序编号
	private String WId;

	// 工序名称
	private String WName;

	// 工序描述
	private String WDescribe;
	
	public static final String WORKSTEP_TABLE_NAME = "apmfp_workstep_table";

	public WorkStep() {
	}

	public WorkStep(String wId, String wName, String wDescribe) {
		super();
		WId = wId;
		WName = wName;
		WDescribe = wDescribe;
	}

	public String getWId() {
		return WId;
	}

	public void setWId(String wId) {
		WId = wId;
	}

	public String getWName() {
		return WName;
	}

	public void setWName(String wName) {
		WName = wName;
	}

	public String getWDescribe() {
		return WDescribe;
	}

	public void setWDescribe(String wDescribe) {
		WDescribe = wDescribe;
	}

	@Override
	public String toString() {
		return "WId=" + WId + ", WName=" + WName + ", WDescribe=" + WDescribe;
	}

	public boolean judge() {

		if (StringUtils.isBlank(WId)) {
			return false;
		}
		if (StringUtils.isBlank(WName)) {
			return false;
		}
	
		return true;

	}
}
