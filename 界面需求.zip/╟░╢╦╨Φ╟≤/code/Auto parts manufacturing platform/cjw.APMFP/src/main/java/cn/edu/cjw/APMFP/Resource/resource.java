package cn.edu.cjw.APMFP.Resource;

import cn.edu.cjw.APMFP.BOMTable.pojo.BOMTable;

public class resource extends BOMTable {

	private Long WareHouseNum;

	// 审核人
	private String ChargeMan;

	public static final String RESOURCE_TABLE_NAME = "apmfp_resource_table";

	public resource() {

	}

	public resource(Long wareHouseNum, String chargeMan) {
		this.WareHouseNum = wareHouseNum;
		this.ChargeMan = chargeMan;
	}

	public void ResetBOM(BOMTable table) {
		
		this.setBId(table.getBId());
		this.setBName(table.getBName());
		this.setBtype(table.getBtype());
		this.setUnit(table.getUnit());

	}

	public Long getWareHouseNum() {
		return WareHouseNum;
	}

	public void setWareHouseNum(Long wareHouseNum) {
		WareHouseNum = wareHouseNum;
	}

	public String getChargeMan() {
		return ChargeMan;
	}

	public void setChargeMan(String chargeMan) {
		ChargeMan = chargeMan;
	}

	@Override
	public String toString() {
		return "WareHouseNum=" + WareHouseNum + ", ChargeMan=" + ChargeMan + " " + super.toString();
	}

}
