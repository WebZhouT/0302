package cn.edu.cjw.APMFP.Product.pojo;

import java.io.Serializable;
import java.util.HashMap;

import org.apache.commons.lang.StringUtils;

import cn.edu.cjw.APMFP.BOMTable.pojo.BOMTable;

public class Product extends BOMTable implements Serializable {

	// 产品所需原料
	// key为所需原料编号，value为生产单个产品所需原料数量
	private HashMap<String, Long> material;

	// 产品生产步骤
	// key为工序顺序，value为工序编号
	private HashMap<Integer, String> workstep;

	public static final String PRODUCT_TABLE_NAME = "apmfp_product_table";

	public Product() {
	}

	public void setProduct(BOMTable bomTable) {
		this.setBId(bomTable.getBId());
		this.setBName(bomTable.getBName());
		this.setBtype(bomTable.getBtype());
		this.setUnit(bomTable.getUnit());
	}

	public Product(HashMap<String, Long> material, HashMap<Integer, String> workstep) {
		super();
		this.material = material;
		this.workstep = workstep;
	}

	public HashMap<String, Long> getMaterial() {
		return material;
	}

	public void setMaterial(HashMap<String, Long> material) {
		this.material = material;
	}

	public HashMap<Integer, String> getWorkstep() {
		return workstep;
	}

	public void setWorkstep(HashMap<Integer, String> workstep) {
		this.workstep = workstep;
	}

	@Override
	public String toString() {
		return "material=" + material + ", workstep=" + workstep + super.toString();
	}

	public boolean ProductJudge() {

		if (StringUtils.isBlank(this.material.toString())) {
			return false;
		}
		if (StringUtils.isBlank(this.workstep.toString())) {
			return false;
		}
		return true;
	}
}
