package cn.edu.cjw.APMFP.FunctionBlock;

import cn.edu.cjw.APMFP.RoleRight.Service.RoleRightService;
import cn.edu.cjw.APMFP.RoleRight.Service.RrServiceImpl;
import cn.edu.cjw.APMFP.user.Service.UserService;
import cn.edu.cjw.APMFP.user.Service.UserServiceImpl;
import cn.edu.cjw.APMFP.user.pojo.user;

public class LoginBlock {

	private LoginBlock() {
		
	}
	
	/**
	 * 登录模块
	 * 
	 * input：当前使用用户 worknow ，用户输入工号 uAccount ，用户输入密码 uPwd
	 * 验证用户账号是否存在->验证用户密码是否匹配->验证用户账号是否停用
	 * output：true->用户进入系统 worknow为用户登录账号 ;
	 * false->提示登录失败，无法进入系统
	 * 
	 * @param uAccount
	 * @param uPwd
	 * @return
	 * @throws Exception 
	 */
	
	public static boolean Login(user worknow,String uAccount,String uPwd) throws Exception {
		
		boolean flag = false;
		
		UserService uService = new UserServiceImpl();
		RoleRightService rService = new RrServiceImpl();
		
		worknow = uService.SearchUserByAccount(uAccount);
		
		if (worknow.judge()) {
			
			if (worknow.getPassWord().equals(uPwd)) {
				
				if (!worknow.isDeactivate()) {
					flag = true;
				}else {
					return flag;
				}
				
			}
			
		}else {
			
			return flag;
			
		}
		
		
		return flag;
	}
}
