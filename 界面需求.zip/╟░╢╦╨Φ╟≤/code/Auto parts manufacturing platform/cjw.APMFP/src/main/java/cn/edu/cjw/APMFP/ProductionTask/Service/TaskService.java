package cn.edu.cjw.APMFP.ProductionTask.Service;

import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;

import cn.edu.cjw.APMFP.ProductionTask.pojo.ProductionTask;
import cn.edu.cjw.APMFP.user.pojo.user;

public interface TaskService {

	//新增任务
	public boolean addTask(String TaskId,String founder,Date creationTime,String chargeMan,Date completionTime,String describe) throws Exception;
	
	//审核任务
	public boolean ExamineTask(ProductionTask task,HashMap<String, Long> product) throws Exception;
	
	//更新任务:更新负责人、更新工期时间、更新进度、更新备注
	public boolean updateTaskchargeMan(ProductionTask task,String chargeMan) throws Exception;
	
	public boolean updateTaskCompletionTime(ProductionTask task,Date time) throws Exception;
	
	public boolean updateTaskPercentage(ProductionTask task,HashMap<String, Boolean> percentage) throws Exception;
	
	//总体修改
	public boolean updateTask(ProductionTask task,String chargeMan,Date time,HashMap<String, Boolean> percentage) throws Exception;
	
	//删除任务
	public boolean removeTask(ProductionTask task) throws Exception;
	
	//按任务单号搜索任务
	public ProductionTask searchTaskById(String TaskId) throws Exception;
	
	//生产中任务
	public ArrayList<ProductionTask> searchTaskByIng() throws Exception;
	
	//未审核任务
	public ArrayList<ProductionTask> searchTaskByExamine() throws Exception;
	
	//生产完成待审核入库任务
	public ArrayList<ProductionTask> searchTaskComplete() throws Exception;
	
	//展示所有任务
	public ArrayList<ProductionTask> showAll() throws Exception;
}
