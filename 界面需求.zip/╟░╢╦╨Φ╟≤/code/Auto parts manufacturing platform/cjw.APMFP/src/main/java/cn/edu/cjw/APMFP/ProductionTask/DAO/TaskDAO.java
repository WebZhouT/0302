package cn.edu.cjw.APMFP.ProductionTask.DAO;

import java.util.ArrayList;

import cn.edu.cjw.APMFP.ProductionTask.pojo.ProductionTask;

public interface TaskDAO {

	// 新增、更新任务
	public boolean addAndUpdateTask(ProductionTask task) throws Exception;
	
	// 删除任务
	public boolean removeTask(ProductionTask task) throws Exception;

	// 搜索任务
	// 按任务单号搜索任务
	public ProductionTask searchTaskById(String id) throws Exception;

	// 生产中任务
	public ArrayList<ProductionTask> searchTaskByIng() throws Exception;

	// 未审核任务
	public ArrayList<ProductionTask> searchTaskByExamine() throws Exception;

	// 生产完成待审核入库任务
	public ArrayList<ProductionTask> searchTaskComplete() throws Exception;
	
	//展示所有任务
	public ArrayList<ProductionTask> showAll() throws Exception;
}
