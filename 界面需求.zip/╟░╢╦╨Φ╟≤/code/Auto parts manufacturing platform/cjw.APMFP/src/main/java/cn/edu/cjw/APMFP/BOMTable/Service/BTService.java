package cn.edu.cjw.APMFP.BOMTable.Service;

import java.util.ArrayList;

import cn.edu.cjw.APMFP.BOMTable.pojo.BOMTable;

public interface BTService {

	//新增资源
	//新增前验证BOM编号是否已存在
	public boolean addBOM(String BId,String BName,String Btype,String unit) throws Exception;
	
	//更新资源，编号唯一不可修改，编辑名称、类型、单位
	public boolean updateBOMName(BOMTable bomTable,String name) throws Exception;
	
	public boolean updateBOMType(BOMTable bomTable,String type) throws Exception;
	
	public boolean UpdateBOMUnit(BOMTable bomTable,String unit) throws Exception;
	
	public boolean updateBOM(BOMTable bomTable,String name,String type,String unit) throws Exception;
	
	//删除资源
	public boolean removeBOM(BOMTable bomTable) throws Exception;
	
	//搜索资源，按编号、名称、类型、单位
	public BOMTable searchById(String id) throws Exception;
	
	public ArrayList<BOMTable> searchByName(String name) throws Exception;
	
	public ArrayList<BOMTable> searchByType(String type) throws Exception;
	
	public ArrayList<BOMTable> searchByUnit(String unit) throws Exception;
	
	//展示所有资源
	public ArrayList<BOMTable> showAll() throws Exception;
}
