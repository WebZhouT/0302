package cn.edu.cjw.APMFP.RoleRight.Service;

import java.util.ArrayList;

import cn.edu.cjw.APMFP.RoleRight.pojo.RoleRight;

public interface RoleRightService {

	//展示所有角色
	public ArrayList<RoleRight> showAll() throws Exception;
	
	//新增角色
	public boolean addRole(RoleRight r) throws Exception;
	
	//删除角色
	public boolean removeRole(RoleRight r) throws Exception;
	
	//修改角色权限
	public boolean updateRoleRight(RoleRight r,ArrayList<String> list) throws Exception;
	
	//修改角色描述
	public boolean updateRoleDescribe(RoleRight r,String newDescribe) throws Exception;
	
	//修改角色名称
	public boolean updateRoleName(RoleRight r,String newName) throws Exception;
	
	//总体修改
	public boolean updateRole(RoleRight r,ArrayList<String> list,String newDescribe,String newName) throws Exception;
	
	//根据角色编号搜索角色
	public RoleRight searchRoleByNum(String rNum) throws Exception;
	
	//根据角色名称搜索角色
	public ArrayList<RoleRight> searchRoleByName(String rName) throws Exception;
}
