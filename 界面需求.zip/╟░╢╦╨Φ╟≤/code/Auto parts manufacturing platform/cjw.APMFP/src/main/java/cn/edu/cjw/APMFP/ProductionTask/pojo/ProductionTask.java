package cn.edu.cjw.APMFP.ProductionTask.pojo;

import java.io.Serializable;
import java.sql.Date;
import java.util.HashMap;

import org.apache.commons.lang.StringUtils;

public class ProductionTask implements Serializable {

	// 任务单号
	private String TaskId;

	// 创建人 String类型，存储创建人账号
	private String founder;

	// 创建时间
	private Date creationTime;

	// 负责人 String类型，存储负责人账号
	private String chargeMan;

	// 要求完成时间(工期)
	private Date completionTime;

	// 审核状态
	private Boolean examine = false;

	// 进度
	// key为工序WorkStep的编号-String类型，value为工序是否执行-Boolean类型
	private HashMap<String, Boolean> percentage;

	// 成品
	// key为产品Product的编号-String类型，value为生产产品的数量-Long类型
	private HashMap<String, Long> product;

	// 原料
	// key为BOMTable类型数据中Type=material的数据的编号-String类型，
	// value为所需此原料的数量—Long类型
	private HashMap<String, Long> material;

	// 备注
	private String describe;

	public static final String TASK_TABLE_NAME = "apmfp_task_table";

	public ProductionTask() {

	}

	public ProductionTask(String taskId, String founder, Date creationTime, String chargeMan, Date completionTime,
			String describe) {
		super();
		TaskId = taskId;
		this.founder = founder;
		this.creationTime = creationTime;
		this.chargeMan = chargeMan;
		this.completionTime = completionTime;
		this.describe = describe;
	}

	public boolean setExamine(HashMap<String, Boolean> percentage, HashMap<String, Long> product,
			HashMap<String, Long> material) {

		if (!this.examine) {

			this.material = material;
			this.product = product;
			this.percentage = percentage;

			this.examine = true;
		}
		
		return examine;

	}

	public String getTaskId() {
		return TaskId;
	}

	public void setTaskId(String taskId) {
		TaskId = taskId;
	}

	public String getFounder() {
		return founder;
	}

	public void setFounder(String founder) {
		this.founder = founder;
	}

	public Date getCreationTime() {
		return creationTime;
	}

	public void setCreationTime(Date creationTime) {
		this.creationTime = creationTime;
	}

	public String getChargeMan() {
		return chargeMan;
	}

	public void setChargeMan(String chargeMan) {
		this.chargeMan = chargeMan;
	}

	public Date getCompletionTime() {
		return completionTime;
	}

	public void setCompletionTime(Date completionTime) {
		this.completionTime = completionTime;
	}

	public Boolean getExamine() {
		return examine;
	}

	public String getDescribe() {
		return describe;
	}

	public void setDescribe(String describe) {
		this.describe = describe;
	}

	public HashMap<String, Boolean> getPercentage() {
		return percentage;
	}

	public void setPercentage(HashMap<String, Boolean> percentage) {
		this.percentage = percentage;
	}

	public HashMap<String, Long> getProduct() {
		return product;
	}

	public void setProduct(HashMap<String, Long> product) {
		this.product = product;
	}

	public HashMap<String, Long> getMaterial() {
		return material;
	}

	public void setMaterial(HashMap<String, Long> material) {
		this.material = material;
	}

	@Override
	public String toString() {
		return "TaskId=" + TaskId + ", founder=" + founder + ", creationTime=" + creationTime
				+ ", chargeMan=" + chargeMan + ", completionTime=" + completionTime + ", examine=" + examine
				+ ", percentage=" + percentage + ", product=" + product + ", material=" + material + ", describe="
				+ describe;
	}

	public boolean judge() {

		if (StringUtils.isBlank(this.TaskId)) {
			return false;
		}
		if (StringUtils.isBlank(this.founder)) {
			return false;
		}
		if (StringUtils.isBlank(this.chargeMan)) {
			return false;
		}
		if (StringUtils.isBlank(this.completionTime.toString())) {
			return false;
		}
		return true;
	}
}
