package cn.edu.cjw.APMFP.power;

import java.util.ArrayList;
import java.util.Scanner;

public class PoweConstant {

	private PoweConstant() {

	}

	// 个人基础权限
	private static final String PERSONAL_BASIC_AUTHORITY = "a";

	// 账号管理基础权限
	private static final String ACCOUNTMANAGE_BASIC = "b";

	// 账号管理超级权限
	private static final String ACCOUNTMANAGE_SUPER = "c";

	// 生产管理基础权限
	private static final String PRODUCTIONMANAGE_BASIC = "d";

	// 生产管理超级权限
	private static final String PRODUCTIONMANAGE_SUPER = "e";

	// 资源管理基础权限
	private static final String RESOURCEMANAGE_BASIC = "f";

	// 资源管理超级权限
	private static final String RESOURCEMANAGE_SUPER = "g";

	public static ArrayList<String> ChoicePower() {

		boolean flag = true;
		Scanner scanner = new Scanner(System.in);
		ArrayList<String> list = new ArrayList<String>();

		while (flag) {

			String line = scanner.nextLine();
			if (line.contains("1")) {
				list.add(PoweConstant.PERSONAL_BASIC_AUTHORITY);
			}
			if (line.contains("2")) {
				list.add(PoweConstant.ACCOUNTMANAGE_BASIC);
			}
			if (line.contains("3")) {
				list.add(PoweConstant.ACCOUNTMANAGE_SUPER);
			}
			if (line.contains("4")) {
				list.add(PoweConstant.PRODUCTIONMANAGE_BASIC);
			}
			if (line.contains("5")) {
				list.add(PoweConstant.PRODUCTIONMANAGE_SUPER);
			}
			if (line.contains("6")) {
				list.add(PoweConstant.RESOURCEMANAGE_BASIC);
			}
			if (line.contains("7")) {
				list.add(PoweConstant.RESOURCEMANAGE_SUPER);
			}
			if (line.contains("8")) {
				flag = false;
			}
		}

		return list;
	}
}
