package cn.edu.cjw.APMFP.cjw.APMFP;

import java.util.ArrayList;
import java.util.HashMap;

import org.junit.Test;

import cn.edu.cjw.APMFP.BOMTable.Service.BTService;
import cn.edu.cjw.APMFP.BOMTable.Service.BTServiceImpl;
import cn.edu.cjw.APMFP.Product.Servicve.ProductService;
import cn.edu.cjw.APMFP.Product.Servicve.ProductServiceImpl;
import cn.edu.cjw.APMFP.Product.pojo.Product;

public class ProductTest {
	
	ProductService service = new ProductServiceImpl();
	BTService bomservice = new BTServiceImpl();
	
	// 新增商品
	@Test
	public void TestaddProduct() {
		
		try {
			
			HashMap<String, Long> material = new HashMap<String, Long>();
			material.put("005", 2l);
			material.put("006", 3l);
			
			HashMap<Integer, String> workstep = new HashMap<Integer, String>();
			workstep.put(1, "mk451659");
			workstep.put(2, "mk451887");
			
			boolean addProduct = service.addProduct(bomservice.searchById("xmode-007"), material, workstep);
			
			System.out.println(addProduct?"1":"0");
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	// 更新商品原料
	@Test
	public void TestupdateProductMaterial() {
		
		try {
			HashMap<String, Long> material = new HashMap<String, Long>();
			material.put("005", 2l);
			
			boolean updateProductMaterial = service.updateProductMaterial(service.searchProductById("001"), material);
			
			System.out.println(updateProductMaterial?"1":"0");
		} catch (Exception e) {
			// TODO: handle exception
		}
		
	}

	// 更新商品工序
	@Test
	public void TestupdateProductWorkstep() {
		
		try {
			HashMap<Integer, String> workstep = new HashMap<Integer, String>();
			workstep.put(1, "mk451659");
			boolean updateProductWorkstep = service.updateProductWorkstep(service.searchProductById("001"), workstep);
			
			System.out.println(updateProductWorkstep?"1":"0");
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		
	}

	// 删除商品
	@Test
	public void TestremoveProduct() {
		
		try {
			boolean removeProduct = service.removeProduct(service.searchProductById("001"));
			
			System.out.println(removeProduct?"1":"0");
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	// 按名称搜索商品
	@Test
	public void TestsearchProductByName() {
		
		try {
			ArrayList<Product> searchProductByName = service.searchProductByName("车前架");
			
			for (Product product : searchProductByName) {
				System.out.println(product);
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
}
