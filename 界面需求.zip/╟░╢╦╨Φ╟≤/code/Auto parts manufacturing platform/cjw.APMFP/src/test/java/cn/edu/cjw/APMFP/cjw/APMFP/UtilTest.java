package cn.edu.cjw.APMFP.cjw.APMFP;

import org.junit.Test;

import cn.edu.cjw.APMFP.BOMTable.pojo.BOMTable;
import cn.edu.cjw.APMFP.Util.SelectExist;

public class UtilTest {

	@Test
	public void TestSelectExist() {

		try {
			System.out.println(SelectExist.selectExist(BOMTable.BOMTABLE_TABLE_NAME, "bid", "001") ? "查有数据" : "查无数据");
			System.out.println(SelectExist.selectExist(BOMTable.BOMTABLE_TABLE_NAME, "bid", "hello") ? "查有数据" : "查无数据");

		} catch (Exception e) {
			// TODO: handle exception
		}

	}
}
