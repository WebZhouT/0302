package cn.edu.cjw.APMFP.cjw.APMFP;

import java.util.ArrayList;
import java.util.Scanner;

import org.junit.Test;

import cn.edu.cjw.APMFP.WorkStep.Service.WsService;
import cn.edu.cjw.APMFP.WorkStep.Service.WsServiceImpl;
import cn.edu.cjw.APMFP.WorkStep.pojo.WorkStep;

public class WorkStepTest {

	WsService WsService = new WsServiceImpl();

	@Test
	public void TestAdd() {

		try {

			WorkStep ws = new WorkStep("mk451781", "改色", "成品改色");

			System.out.println(ws);
			boolean addWStep = WsService.AddWStep(ws.getWId(), ws.getWName(), ws.getWDescribe());

			System.out.println(addWStep ? "1" : "0");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Test
	public void TestRemove() {

		try {
			ArrayList<WorkStep> showAll = WsService.showAll();

			for (WorkStep workStep : showAll) {
				System.out.println(workStep);
			}

			Scanner scanner = new Scanner(System.in);

			System.out.println("请输入将要删除的工序编号：");

			System.out.println(WsService.removeWStep(WsService.searchWStepById(scanner.nextLine())) ? "1" : "0");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

	}

	@Test
	public void TestupdateWSName() {

		try {
			ArrayList<WorkStep> showAll = WsService.showAll();

			for (WorkStep workStep : showAll) {
				System.out.println(workStep);
			}

			Scanner scanner = new Scanner(System.in);

			System.out.println("请输入将要修改的工序编号：");
			WorkStep searchWStepById = WsService.searchWStepById(scanner.nextLine());

			System.out.println("请输入修改的新名称");

			System.out.println(WsService.updateWStepName(searchWStepById, scanner.nextLine()) ? "1" : "0");
		} catch (Exception e) {
			// TODO: handle exception
		}

	}

	@Test
	public void TestupdateWSDescribe() {

		try {
			ArrayList<WorkStep> showAll = WsService.showAll();

			for (WorkStep workStep : showAll) {
				System.out.println(workStep);
			}

			Scanner scanner = new Scanner(System.in);

			System.out.println("请输入将要修改的工序编号：");
			WorkStep searchWStepById = WsService.searchWStepById(scanner.nextLine());

			System.out.println("请输入修改的新备注");

			System.out.println(WsService.updateWStepDescribe(searchWStepById, scanner.nextLine()) ? "1" : "0");
		} catch (Exception e) {
			// TODO: handle exception
		}

	}

	@Test
	public void TestSearchByName() {

		try {

			Scanner scanner = new Scanner(System.in);

			System.out.println("请输入您要搜索的工序名称");

			ArrayList<WorkStep> searchWStepByName = WsService.searchWStepByName(scanner.nextLine());

			for (WorkStep workStep : searchWStepByName) {

				System.out.println(workStep);
			}

		} catch (Exception e) {
			// TODO: handle exception
		}

	}

}
