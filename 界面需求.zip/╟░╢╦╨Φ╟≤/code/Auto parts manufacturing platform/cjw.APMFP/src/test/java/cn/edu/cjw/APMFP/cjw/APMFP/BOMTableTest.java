package cn.edu.cjw.APMFP.cjw.APMFP;

import java.util.ArrayList;

import org.junit.Test;

import cn.edu.cjw.APMFP.BOMTable.Service.BTService;
import cn.edu.cjw.APMFP.BOMTable.Service.BTServiceImpl;
import cn.edu.cjw.APMFP.BOMTable.pojo.BOMTable;

public class BOMTableTest {
	
	BTService service = new BTServiceImpl();
	
	// 新增资源
	// 新增前验证BOM编号是否已存在
	@Test
	public void TestaddBOM() {
		
		try {
			boolean addBOM = service.addBOM("xmode-007", "车前架", BOMTable.TYPE_PRODUCT, "个");
			
			System.out.println(addBOM?"1":"0");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	// 更新资源，Test编号唯一不可修改，编辑名称、类型、单位
	@Test
	public void TestupdateBOMName(){
		
		try {
			boolean updateBOMName = service.updateBOMName(service.searchById("005"),"车前架模");
			System.out.println(updateBOMName?"1":"0");
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Test
	public void TestupdateBOMType() {
		
		try {
			boolean updateBOMType = service.updateBOMType(service.searchById("001"), BOMTable.TYPE_PRODUCT);
			System.out.println(updateBOMType?"1":"0");
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		
	}

	@Test
	public void TestUpdateBOMUnit() {
		
		try {
			
			boolean updateBOMUnit = service.UpdateBOMUnit(service.searchById("001"), "支");
			
			System.out.println(updateBOMUnit?"1":"0");
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	// 删除资源
	@Test
	public void TestremoveBOM() {
		
		try {
			boolean removeBOM = service.removeBOM(service.searchById("001"));
			System.out.println(removeBOM?"1":"0");
		} catch (Exception e) {
			// TODO: handle exception
		}
		
	}

	// 搜索资源 按名称、类型、单位
	@Test
	public void TestsearchByName() {
		
		try {
			ArrayList<BOMTable> searchByName = service.searchByName("车前架");
			
			System.out.println(searchByName);
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	@Test
	public void TestsearchByType() {
		
		try {
			ArrayList<BOMTable> searchByType = service.searchByType(BOMTable.TYPE_MATERIAL);
			
			System.out.println(searchByType);
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	@Test
	public void TestsearchByUnit() {
		
		try {
			ArrayList<BOMTable> searchByUnit = service.searchByUnit("个");
			
			System.out.println(searchByUnit);
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	// 展示所有
	@Test
	public void TestshowAll() {
		
		try {
			ArrayList<BOMTable> showAll = service.showAll();
			
			for (BOMTable bomTable : showAll) {
				
				System.out.println(bomTable);
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
}
