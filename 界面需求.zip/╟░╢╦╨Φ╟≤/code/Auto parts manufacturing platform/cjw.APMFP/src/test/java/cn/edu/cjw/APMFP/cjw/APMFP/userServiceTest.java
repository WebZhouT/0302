package cn.edu.cjw.APMFP.cjw.APMFP;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

import org.junit.Test;

import cn.edu.cjw.APMFP.RoleRight.Service.RoleRightService;
import cn.edu.cjw.APMFP.RoleRight.Service.RrServiceImpl;
import cn.edu.cjw.APMFP.RoleRight.pojo.RoleRight;
import cn.edu.cjw.APMFP.user.Service.UserService;
import cn.edu.cjw.APMFP.user.Service.UserServiceImpl;
import cn.edu.cjw.APMFP.user.pojo.user;

public class userServiceTest {

	private UserService us = new UserServiceImpl();
	private RoleRightService rrs = new RrServiceImpl();

	@Test
	public void TestAddUser() {

		try {
			Scanner scanner = new Scanner(System.in);

			user user = new user();
			user.setAccount("test01");
			user.setAge(18);
			user.setGender("famale");
			user.setName("YiYi");

			System.out.println("请选择员工角色，输入角色对应编号即可：");
			ArrayList<RoleRight> showAll = rrs.showAll();
			for (RoleRight roleRight : showAll) {
				System.out.println(roleRight);
			}
			String nextLine = scanner.nextLine();
			RoleRight searchRoleByNum = rrs.searchRoleByNum(nextLine);
			user.setuRole(searchRoleByNum);

			System.out.println(user);

			boolean addUser = us.addUser(user);
			System.out.println(addUser ? "操作成功" : "操作失败");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Test
	public void TestRemoveUser() {

		try {
			user searchUserByAccount = us.SearchUserByAccount("58691052IT");
			System.out.println(searchUserByAccount);
			boolean removeUSer = us.removeUSer(searchUserByAccount);

			System.out.println(removeUSer ? "操作成功" : "操作失败");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Test
	public void TestShowAll() {

		try {
			ArrayList<user> showAll = us.showAll();
			for (user user : showAll) {

				System.out.println(user);
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void TestupdateUserPassword() {

		try {
			Scanner scanner = new Scanner(System.in);

			System.out.println("请输入您要修改的员工员工账号：");
			ArrayList<user> showAll = us.showAll();
			for (user user2 : showAll) {
				System.out.println(user2);
			}

			user searchUserByAccount = us.SearchUserByAccount(scanner.nextLine());

			System.out.println("请输入原密码：");
			String newAccount = scanner.nextLine();

			if (searchUserByAccount.getPassWord().equals(newAccount)) {

				System.out.println(searchUserByAccount);

				System.out.println("请输入新密码：");
				boolean updateUserPassword = us.updateUserPassword(searchUserByAccount, scanner.nextLine());
				System.out.println(updateUserPassword ? "操作成功" : "操作失败");

			} else {

				System.out.println("密码不匹配！");
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Test
	public void TestupdateUserName() {

		try {
			Scanner scanner = new Scanner(System.in);

			System.out.println("请输入您要修改的员工员工账号：");
			ArrayList<user> showAll = us.showAll();
			for (user user2 : showAll) {
				System.out.println(user2);
			}

			user searchUserByAccount = us.SearchUserByAccount(scanner.nextLine());

			System.out.println("请输入新姓名：");
			System.out.println(us.updateUserName(searchUserByAccount, scanner.nextLine()) ? "操作成功" : "操作失败");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Test
	public void TestupdateUserRole() {

		try {
			Scanner scanner = new Scanner(System.in);

			System.out.println("请输入您要修改的员工员工账号：");
			ArrayList<user> showAll = us.showAll();
			for (user user2 : showAll) {
				System.out.println(user2);
			}

			user searchUserByAccount = us.SearchUserByAccount(scanner.nextLine());

			System.out.println("请选择新角色，并输入角色编号：");
			ArrayList<RoleRight> showAll2 = rrs.showAll();
			for (RoleRight roleRight : showAll2) {

				System.out.println(roleRight);
			}

			RoleRight searchRoleByNum = rrs.searchRoleByNum(scanner.nextLine());
			us.updateUserRole(searchUserByAccount, searchRoleByNum);
			System.out.println(us.updateUserRole(searchUserByAccount, searchRoleByNum) ? "操作成功" : "操作失败");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Test
	public void TestupdateUserGender() {

		try {
			Scanner scanner = new Scanner(System.in);

			System.out.println("请输入您要修改的员工员工账号：");
			ArrayList<user> showAll = us.showAll();
			for (user user2 : showAll) {
				System.out.println(user2);
			}

			user searchUserByAccount = us.SearchUserByAccount(scanner.nextLine());

			System.out.println("请输入角色性别：");
			System.out.println(us.updateUserGender(searchUserByAccount, scanner.nextLine()) ? "操作成功" : "操作失败");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void TestupdateUserAge() {
		
		try {
			Scanner scanner = new Scanner(System.in);

			System.out.println("请输入您要修改的员工员工账号：");
			ArrayList<user> showAll = us.showAll();
			for (user user2 : showAll) {
				System.out.println(user2);
			}

			user searchUserByAccount = us.SearchUserByAccount(scanner.nextLine());

			System.out.println("请输入角色年龄：");
			System.out.println(us.updateUserAge(searchUserByAccount, Integer.parseInt(scanner.nextLine())) ? "操作成功" : "操作失败");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void TestupdateUserIsdeactivate() {
		try {
			Scanner scanner = new Scanner(System.in);

			System.out.println("请输入您要修改的员工员工账号：");
			ArrayList<user> showAll = us.showAll();
			for (user user2 : showAll) {
				System.out.println(user2);
			}

			user searchUserByAccount = us.SearchUserByAccount(scanner.nextLine());

			boolean flag ;
			if (!searchUserByAccount.isDeactivate()) {
				flag = true;
			}else {
				flag = false;
			}
			System.out.println(us.updateUserIsdeactivate(searchUserByAccount, flag) ? "操作成功" : "操作失败");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void TestSearchUserByAccount() {
		
		try {
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("请输入要搜索的员工工号：");
			user searchUserByAccount = us.SearchUserByAccount(scanner.nextLine());
			if (searchUserByAccount != null) {
				System.out.println(searchUserByAccount);
			}else {
				System.out.println("error!");
			}
				
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void TestSearchUserByName() {
		
		try {
			Scanner scanner = new Scanner(System.in);
			
			System.out.println("请输入要搜索的员工姓名：");
				ArrayList<user> searchUserByName = us.SearchUserByName(scanner.nextLine());
				for (user user : searchUserByName) {
					
					System.out.println(user);
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}

	@Test
	public void TestSearchUserByRole() {
		
		try {
			Scanner scanner = new Scanner(System.in);
			
			System.out.println("请输入要搜索的员工的角色编号：");
			
			RoleRight searchRoleByNum = rrs.searchRoleByNum(scanner.nextLine());
			
				ArrayList<user> searchUserByRole = us.SearchUserByRole(searchRoleByNum);
				
				for (user user : searchUserByRole) {
					System.out.println(user);
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		
	}
	
}
