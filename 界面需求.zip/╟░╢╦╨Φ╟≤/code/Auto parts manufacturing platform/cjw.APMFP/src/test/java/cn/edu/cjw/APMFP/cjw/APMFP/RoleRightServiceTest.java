package cn.edu.cjw.APMFP.cjw.APMFP;

import java.util.ArrayList;
import java.util.Scanner;

import org.junit.Test;

import cn.edu.cjw.APMFP.RoleRight.Service.RoleRightService;
import cn.edu.cjw.APMFP.RoleRight.Service.RrServiceImpl;
import cn.edu.cjw.APMFP.RoleRight.pojo.RoleRight;
import cn.edu.cjw.APMFP.power.PoweConstant;

public class RoleRightServiceTest {

	@Test
	public void TestAddRole() {

		RoleRightService rrs = new RrServiceImpl();

		RoleRight roleRight = new RoleRight("7349662-role", "部门主管", "负责所在部门业务", PoweConstant.ChoicePower());

		boolean addRole;
		try {
			addRole = rrs.addRole(roleRight);
			System.out.println(addRole ? "操作成功" : "操作失败");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Test
	public void TestRemove() {
		RoleRightService rrs = new RrServiceImpl();
		
		
		System.out.println("请输入要删除的角色编号：");
		RoleRight r;
		try {
			r = rrs.searchRoleByNum(new Scanner(System.in).nextLine());
			
			if (r.judge()) {
				System.out.println(rrs.removeRole(r)?"操作成功":"操作失败");				
			}else {
				System.out.println("角色编号所对应的角色不存在！");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

	@Test
	public void TestUpdate() {

		RoleRightService rrs = new RrServiceImpl();

		try {
			ArrayList<RoleRight> searchRoleByName = rrs.searchRoleByName("经理");
			RoleRight roleRight = searchRoleByName.get(0);

			boolean updateRoleDescribe = rrs.updateRoleDescribe(roleRight, "负责所在公司业务");
			System.out.println(updateRoleDescribe ? "修改成功" : "修改失败");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Test
	public void TestSearch() {
		RoleRightService rrs = new RrServiceImpl();

		try {
			ArrayList<RoleRight> searchRoleByName = rrs.searchRoleByName("主管");
			
			for (RoleRight roleRight : searchRoleByName) {
				System.out.println("按名搜索"+roleRight);
			}
			
			RoleRight searchRoleByNum = rrs.searchRoleByNum("7349660-role");
			
			System.out.println("按号搜索"+searchRoleByName);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}


	@Test
	public void TestShowAll() {

		RoleRightService rrs = new RrServiceImpl();
		ArrayList<RoleRight> showAll;
		try {
			showAll = rrs.showAll();
			for (RoleRight roleRight : showAll) {
				System.out.println(roleRight);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
