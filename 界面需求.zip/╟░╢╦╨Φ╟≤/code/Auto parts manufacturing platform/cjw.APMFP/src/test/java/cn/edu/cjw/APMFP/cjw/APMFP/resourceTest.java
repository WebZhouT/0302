package cn.edu.cjw.APMFP.cjw.APMFP;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.Connection;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Table;
import org.apache.hadoop.hbase.util.Bytes;
import org.junit.Test;

import cn.edu.cjw.APMFP.BOMTable.Service.BTService;
import cn.edu.cjw.APMFP.BOMTable.Service.BTServiceImpl;
import cn.edu.cjw.APMFP.BOMTable.pojo.BOMTable;
import cn.edu.cjw.APMFP.ProductionTask.pojo.ProductionTask;
import cn.edu.cjw.APMFP.Resource.resource;
import cn.edu.cjw.APMFP.Resource.Service.ResourceService;
import cn.edu.cjw.APMFP.Resource.Service.ResourceServiceImpl;
import cn.edu.cjw.APMFP.Util.HBaseUtill;
import cn.edu.cjw.APMFP.user.Service.UserService;
import cn.edu.cjw.APMFP.user.Service.UserServiceImpl;
import cn.edu.cjw.APMFP.user.pojo.user;

public class resourceTest {

	private ResourceService service = new ResourceServiceImpl();

	private BTService bomService = new BTServiceImpl();

	private UserService userService = new UserServiceImpl();

	// 原料入库
	@Test
	public void TestmaterialIn() {
		try {

			Scanner scanner = new Scanner(System.in);

			System.out.println("--请选择您想要入库的BOM物资，并输入编号--");
			ArrayList<BOMTable> showAll = bomService.searchByType(BOMTable.TYPE_MATERIAL);
			for (BOMTable bomTable : showAll) {
				System.out.println(bomTable);
			}
			BOMTable searchById = bomService.searchById(scanner.nextLine());

			System.out.println("--请输入入库数量--");
			Long num = Long.valueOf(scanner.nextLine());

			resource resource = new resource(num, "586910525T");
			resource.ResetBOM(searchById);
			
			System.out.println(resource.getWareHouseNum());
			
			boolean materialIn = service.materialIn(searchById, num, userService.SearchUserByAccount("586910525T"));

			System.out.println(materialIn ? "1" : "0");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// 原料出库
	@Test
	public void TestmaterialOut() {

		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			ProductionTask task = new ProductionTask("001", "test", new Date(System.currentTimeMillis()),
					"testChargeMan",new Date(sdf.parse("2022-03-24").getTime()), "Test");

			HashMap<String, Boolean> precentage = new HashMap<String, Boolean>();
			precentage.put("test", false);

			HashMap<String, Long> product = new HashMap<String, Long>();
			product.put("001", 100l);

			HashMap<String, Long> material = new HashMap<String, Long>();
			material.put("001", 300l);

			task.setExamine(precentage, product, material);

			boolean materialOut = service.materialOut(task, userService.SearchUserByAccount("586910525T"));

			System.out.println(materialOut ? "1" : "0");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

	}

	// 产品入Test库
	@Test
	public void TestproductIn() {

		try {

			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

			ProductionTask task = new ProductionTask("001", "test", new Date(System.currentTimeMillis()),
					"testChargeMan", new Date(sdf.parse("2022-03-24").getTime()), "Test");

			HashMap<String, Boolean> precentage = new HashMap<String, Boolean>();
			precentage.put("test", true);

			HashMap<String, Long> product = new HashMap<String, Long>();
			product.put("001", 100l);

			HashMap<String, Long> material = new HashMap<String, Long>();
			material.put("001", 300l);

			task.setExamine(precentage, product, material);

			boolean productIn = service.productIn(task, userService.SearchUserByAccount("586910525T"));

			System.out.println(productIn ? "1" : "0");
		} catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
		}
	}

	// 产品出库
	@Test
	public void TestproductOut() {

		try {
			/**
			 * 在In基础上测试Out
			 */
			Scanner scanner = new Scanner(System.in);

			System.out.println("--请选择您想要出库的BOM物资，并输入编号--");
			ArrayList<BOMTable> showAll = bomService.showAll();
			for (BOMTable bomTable : showAll) {
				System.out.println(bomTable);
			}
			BOMTable searchById = bomService.searchById(scanner.nextLine());

			System.out.println("--请输入出库数量--");
			Long num = new Long(scanner.nextLine());

			boolean productOut = service.productOut(searchById, num, new user());

			System.out.println(productOut ? "1" : "0");
		} catch (Exception e) {
			// TODO: handle exception
		}

	}

	// 删除资源
	@Test
	public void TestremoveResource() {

		try {
			// 输入id需为在表数据
			System.out.println(service.removeResource("005") ? "1" : "0");
			System.out.println(service.removeResource("002") ? "1" : "0");
		} catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
		}
	}

	// 展示原料库存
	@Test
	public void TestshowMaterial() {

		try {
			ArrayList<resource> showMaterial = service.showMaterial();

			for (resource resource : showMaterial) {
				System.out.println(resource);
			}
		} catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
		}
	}

	// 展示产品库存
	@Test
	public void TestshowProduct() {
		try {
			ArrayList<resource> showProduct = service.showProduct();

			for (resource resource : showProduct) {
				System.out.println(resource);
			}
		} catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
		}
	}

	// 按名称搜索库存
	@Test
	public void TestsearchResourceByName() {

		try {
			// test需为在表数据
			ArrayList<resource> searchResourceByName = service.searchResourceByName("test");

			for (resource resource : searchResourceByName) {

				System.out.println(resource);
			}
		} catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
		}
	}

	// 按编号搜索库存
	@Test
	public void TestsearchResourceById() {
		try {

			System.out.println(service.searchResourceById("001"));
		} catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
		}

	}

	@Test
	public void Test() {
		long value = 100l;
		byte[] bytes = Bytes.toBytes(value);
		System.out.println(bytes);
		
		String string = new String(bytes);
		System.out.println(string);
		
		long long1 = Bytes.toLong(bytes);
		System.out.println(long1);
		
		String valueOf = String.valueOf(value);
		System.out.println(valueOf);
	}
}
