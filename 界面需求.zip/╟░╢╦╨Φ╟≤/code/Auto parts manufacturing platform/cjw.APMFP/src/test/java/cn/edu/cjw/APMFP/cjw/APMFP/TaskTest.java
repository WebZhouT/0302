package cn.edu.cjw.APMFP.cjw.APMFP;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import org.junit.Test;

import cn.edu.cjw.APMFP.ProductionTask.Service.TaskService;
import cn.edu.cjw.APMFP.ProductionTask.Service.TaskServiceImpl;
import cn.edu.cjw.APMFP.ProductionTask.pojo.ProductionTask;

public class TaskTest {

	TaskService Service = new TaskServiceImpl();

	// 新增任务
	@Test
	public void TestaddTask() {
		try {
			java.util.Date date = new java.util.Date();
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
			String s = simpleDateFormat.format(date);

			boolean addTask = Service.addTask("test5579686", "586910537DEV", Date.valueOf(s), "test01",
					Date.valueOf("2022-05-19"), "test01");

			System.out.println(addTask);

			System.out.println(addTask ? "1" : "0");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	// 审核任务
	@Test
	public void TestExamineTask() {
		
		try {
			
			HashMap<String, Long> product = new HashMap<String, Long>();
			product.put("001", 50l);
			product.put("xmode-007", 100l);
			
			boolean examineTask = Service.ExamineTask(Service.searchTaskById("test5579686"), product);
			
			System.out.println(examineTask?"1":"0");
		} catch (Exception e) {
			// TODO: handle exception
		}
		
	}

	// 更新任务:更新负责人、更新工期时间、更新进度、更新备注
	@Test
	public void TestupdateTaskchargeMan() {
		
		try {
			
			boolean updateTaskchargeMan = Service.updateTaskchargeMan(Service.searchTaskById("task170954699"), "test01");
			System.out.println(updateTaskchargeMan?"1":"0");
			
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	@Test
	public void TestupdateTaskCompletionTime() {
		
		try {
			boolean updateTaskCompletionTime = Service.updateTaskCompletionTime(Service.searchTaskById("task170954699"), Date.valueOf("2022-03-01"));
			System.out.println(updateTaskCompletionTime?"1":"0");
			
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	@Test
	public void TestupdateTaskPercentage() {
		
		try {
			HashMap<String,Boolean> percentage = Service.searchTaskById("task170954699").getPercentage();
			
			percentage.put("mk451887", true);
			
			boolean updateTaskPercentage = Service.updateTaskPercentage(Service.searchTaskById("task170954699"), percentage);
			
			System.out.println(updateTaskPercentage?"1":"0");
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	// 删除任务
	@Test
	public void TestremoveTask() {
		
		try {
			boolean removeTask = Service.removeTask(Service.searchTaskById("task170954699"));
			System.out.println(removeTask?"1":"0");
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	// 生产中任务
	@Test
	public void TestsearchTaskByIng() {
		
		try {
			ArrayList<ProductionTask> searchTaskByIng = Service.searchTaskByIng();
			
			for (ProductionTask productionTask : searchTaskByIng) {
				
				System.out.println(productionTask);
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	// 未审核任务
	@Test
	public void TestsearchTaskByExamine() {
		
		try {
			ArrayList<ProductionTask> searchTaskByExamine = Service.searchTaskByExamine();
			for (ProductionTask productionTask : searchTaskByExamine) {
				
				System.out.println(productionTask);
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	// 生产完成待审核入库任务
	@Test
	public void TestsearchTaskComplete() {
		
		try {
			ArrayList<ProductionTask> searchTaskComplete = Service.searchTaskComplete();
			
			for (ProductionTask productionTask : searchTaskComplete) {
				
				System.out.println(productionTask);
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
}
